import React from 'react';
import './Confirm.css';


interface ConfirmProps{
  title : string;
  content : string;
  cancelCaption? : string;
  okCaption? :string;
  onOkClick: () => void;
  onCancelClick: () => void;
}


// const Confirm = ({title,content,cancelCaption,okCaption,onOkClick,onCancelClick}:IProps) => {

const Confirm = (props: ConfirmProps) => {
  const {title, content, cancelCaption, okCaption, onOkClick, onCancelClick}= props;

  const handleOkClick = () => {
    onOkClick();
  };

  const handleCancelClick = () => {
    onCancelClick();
  };
  
  return (
    <div className="confirm-wrapper confirm-visible">
      <div className="confirm-container">
        <div className="confirm-title-container">        
          <span>{title}</span>
        </div>
        <div className="confirm-content-container">
          <p>{content}</p>
        </div>
        <div className="confirm-buttons-container">
          <button className="confirm-cancel" onClick ={handleCancelClick}>{cancelCaption}</button>
          <button className="confirm-ok" onClick={handleOkClick}>{okCaption}</button>
        </div>
      </div>
    </div>
  );
}

export default Confirm;
