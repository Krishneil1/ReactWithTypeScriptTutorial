import React from 'react';
import logo from './logo.svg';
import './App.css';
import Confirm from './Confirm';



const handleCancelConfirmClick = () => {
  console.log("Cancel clicked");
};

const handleOkConfirmClick = () => {
  console.log("Ok clicked");
};
function App() {
  
  return (
    <div className="App">
      <Confirm 
      title = 'React and TypeScript' 
      content = 'Are you sure you want to learn React and TypeScript?'
      cancelCaption="No way"
      okCaption="Yes please!"
      onOkClick={handleOkConfirmClick}
      onCancelClick={handleCancelConfirmClick}
      />
      
    </div>
  );
}

export default App;
